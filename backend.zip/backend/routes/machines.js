const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const MachineSchema = new mongoose.Schema({}, { strict: false });
const Machine = mongoose.model('Machine', MachineSchema);

router.get('/', async (req, res) => res.json(await Machine.find()));
router.post('/', async (req, res) => res.json(await Machine.create(req.body)));
router.put('/:id', async (req, res) => res.json(await Machine.findByIdAndUpdate(req.params.id, req.body, { new: true })));
router.delete('/:id', async (req, res) => res.json(await Machine.findByIdAndDelete(req.params.id)));

module.exports = router;
