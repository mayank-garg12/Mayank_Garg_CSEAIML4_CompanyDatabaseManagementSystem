const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({}, { strict: false });
const Project = mongoose.model('Project', ProjectSchema);

router.get('/', async (req, res) => res.json(await Project.find()));
router.post('/', async (req, res) => res.json(await Project.create(req.body)));
router.put('/:id', async (req, res) => res.json(await Project.findByIdAndUpdate(req.params.id, req.body, { new: true })));
router.delete('/:id', async (req, res) => res.json(await Project.findByIdAndDelete(req.params.id)));

module.exports = router;
