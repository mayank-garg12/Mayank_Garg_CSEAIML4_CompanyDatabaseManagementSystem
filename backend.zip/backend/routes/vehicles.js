const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

const VehicleSchema = new mongoose.Schema({}, { strict: false });
const Vehicle = mongoose.model('Vehicle', VehicleSchema);

router.get('/', async (req, res) => res.json(await Vehicle.find()));
router.post('/', async (req, res) => res.json(await Vehicle.create(req.body)));
router.put('/:id', async (req, res) => res.json(await Vehicle.findByIdAndUpdate(req.params.id, req.body, { new: true })));
router.delete('/:id', async (req, res) => res.json(await Vehicle.findByIdAndDelete(req.params.id)));

module.exports = router;
