const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const authRoutes = require('./routes/auth');
const employeeRoutes = require('./routes/employees');
const machineRoutes = require('./routes/machines');
const projectRoutes = require('./routes/projects');
const vehicleRoutes = require('./routes/vehicles');
const verifyToken = require('./middleware/auth');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/companyDashboard');

app.use('/api/auth', authRoutes);
app.use('/api/employees', verifyToken, employeeRoutes);
app.use('/api/machines', verifyToken, machineRoutes);
app.use('/api/projects', verifyToken, projectRoutes);
app.use('/api/vehicles', verifyToken, vehicleRoutes);

app.listen(5000, () => console.log('Server running on port 5000'));
